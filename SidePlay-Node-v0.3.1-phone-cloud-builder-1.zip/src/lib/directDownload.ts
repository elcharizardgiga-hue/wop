import { registerPlugin } from '@capacitor/core'
import { isNative } from './nativeAudio'

type DirectDownloadPlugin = {
  start(options: { url: string; filename?: string }): Promise<{ id: string; destination?: string }>
}

const DirectDownload = registerPlugin<DirectDownloadPlugin>('DirectDownload')
const PC_BRIDGE = 'http://127.0.0.1:4783'

export async function startDirectDownload(url: string, filename?: string) {
  const parsed = new URL(url)
  if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Only http(s) media URLs are supported.')
  if (isNative()) return DirectDownload.start({ url, filename })

  const response = await fetch(`${PC_BRIDGE}/api/direct-download`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ url, filename }),
  })
  const body = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(body?.error || `Direct download failed (${response.status}).`)
  return body as { id: string; destination?: string }
}
