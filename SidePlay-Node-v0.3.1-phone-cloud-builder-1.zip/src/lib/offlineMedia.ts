import { registerPlugin } from '@capacitor/core'
import type { OfflineCopy, Track } from '../types'
import { isNative } from './nativeAudio'

interface OfflineMediaPlugin {
  importAudio(options: { videoId: string; title: string }): Promise<{
    localUri: string
    filename: string
    mimeType?: string
    bytes?: number
  }>
  remove(options: { localUri: string }): Promise<void>
}

const OfflineMedia = registerPlugin<OfflineMediaPlugin>('OfflineMedia')
const PC_BRIDGE = 'http://127.0.0.1:4783'

function pickBrowserAudio(): Promise<File> {
  return new Promise((resolve, reject) => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = 'audio/*,.mp3,.m4a,.aac,.ogg,.opus,.flac,.wav,.webm'
    input.style.display = 'none'
    document.body.appendChild(input)
    let settled = false
    const finish = (file?: File) => {
      if (settled) return
      settled = true
      window.removeEventListener('focus', onFocus)
      input.remove()
      if (!file) return reject(new Error('Import cancelled.'))
      if (!file.size) return reject(new Error('The selected audio file is empty.'))
      const ext = file.name.toLowerCase().split('.').pop() || ''
      const allowed = new Set(['mp3','m4a','aac','ogg','opus','flac','wav','webm'])
      if (file.type && !file.type.startsWith('audio/') && !allowed.has(ext)) return reject(new Error('Please choose a supported audio file.'))
      resolve(file)
    }
    const onFocus = () => window.setTimeout(() => { if (!settled && !input.files?.length) finish() }, 250)
    input.onchange = () => finish(input.files?.[0])
    input.oncancel = () => finish()
    window.addEventListener('focus', onFocus)
    input.click()
  })
}

export async function importOfflineCopy(track: Track): Promise<OfflineCopy> {
  if (isNative()) {
    const result = await OfflineMedia.importAudio({ videoId: track.videoId, title: track.title })
    return {
      videoId: track.videoId,
      localUri: result.localUri,
      filename: result.filename,
      mimeType: result.mimeType,
      bytes: result.bytes,
      addedAt: Date.now(),
      platform: 'android',
      title: track.title, channel: track.channel, thumbnail: track.thumbnail,
    }
  }

  const file = await pickBrowserAudio()
  const key = `${track.videoId}-${Date.now()}`
  const response = await fetch(`${PC_BRIDGE}/api/offline/import?key=${encodeURIComponent(key)}`, {
    method: 'POST',
    headers: {
      'content-type': file.type || 'application/octet-stream',
      'x-sideplay-filename': encodeURIComponent(file.name),
    },
    body: file,
  })
  const body = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(body?.error || `Offline import failed (${response.status}). Start SidePlay with START_SIDEPLAY.bat so the PC bridge is running.`)
  return {
    videoId: track.videoId,
    localUri: body.localUri,
    filename: body.filename || file.name,
    mimeType: body.mimeType || file.type,
    bytes: body.bytes || file.size,
    addedAt: Date.now(),
    platform: 'pc',
    title: track.title, channel: track.channel, thumbnail: track.thumbnail,
  }
}

export async function removeOfflineCopy(copy: OfflineCopy) {
  if (copy.platform === 'android' && isNative()) {
    await OfflineMedia.remove({ localUri: copy.localUri })
    return
  }
  if (copy.platform === 'pc' && !isNative()) {
    const response = await fetch(`${PC_BRIDGE}/api/offline?uri=${encodeURIComponent(copy.localUri)}`, { method: 'DELETE' })
    if (!response.ok && response.status !== 404) {
      const body = await response.json().catch(() => ({}))
      throw new Error(body?.error || 'Could not delete offline file.')
    }
  }
}

export function formatBytes(bytes?: number) {
  if (!bytes || bytes <= 0) return 'Local copy'
  const units = ['B', 'KB', 'MB', 'GB']
  let n = bytes
  let i = 0
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++ }
  return `${n >= 100 || i === 0 ? Math.round(n) : n.toFixed(1)} ${units[i]}`
}
