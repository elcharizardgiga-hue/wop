package app.sideplay.mobile;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.webkit.URLUtil;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "DirectDownload")
public class DirectDownloadPlugin extends Plugin {
    @PluginMethod
    public void start(PluginCall call) {
        String url = call.getString("url");
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) {
            call.reject("Only http(s) direct media URLs are supported.");
            return;
        }

        try {
            String host = Uri.parse(url).getHost();
            String h = host == null ? "" : host.toLowerCase();
            if (h.equals("youtube.com") || h.endsWith(".youtube.com") || h.equals("youtu.be") || h.endsWith(".googlevideo.com")) {
                call.reject("YouTube media downloads are not supported by SidePlay.");
                return;
            }
        } catch (Exception ignored) {}

        String requested = call.getString("filename");
        String filename = (requested == null || requested.trim().isEmpty())
                ? URLUtil.guessFileName(url, null, null)
                : sanitize(requested.trim());

        try {
            DownloadManager manager = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(filename);
            request.setDescription("Downloaded by SidePlay");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);

            String destination;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                destination = "Downloads/" + filename;
            } else {
                request.setDestinationInExternalFilesDir(getContext(), Environment.DIRECTORY_DOWNLOADS, filename);
                destination = "SidePlay app files/Downloads/" + filename;
            }

            long id = manager.enqueue(request);
            JSObject out = new JSObject();
            out.put("id", Long.toString(id));
            out.put("destination", destination);
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Android download failed: " + e.getMessage());
        }
    }

    private String sanitize(String input) {
        return input.replaceAll("[\\\\/:*?\"<>|]", "_");
    }
}
