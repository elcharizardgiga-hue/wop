package app.sideplay.mobile;

import android.content.Intent;
import android.net.Uri;

import androidx.annotation.Nullable;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public class PlaybackService extends MediaSessionService {
    public static final String ACTION_PLAY = "app.sideplay.mobile.PLAY";
    public static final String ACTION_PAUSE = "app.sideplay.mobile.PAUSE";
    public static final String ACTION_RESUME = "app.sideplay.mobile.RESUME";
    public static final String ACTION_STOP = "app.sideplay.mobile.STOP";
    public static final String ACTION_EVENT = "app.sideplay.mobile.PLAYBACK_EVENT";

    private static volatile PlaybackService instance;
    private ExoPlayer player;
    private MediaSession mediaSession;

    public static @Nullable PlaybackService getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        player = new ExoPlayer.Builder(this)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build();

        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build();
        player.setAudioAttributes(audioAttributes, true);
        player.setHandleAudioBecomingNoisy(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                broadcast(isPlaying ? "playing" : "paused", null);
            }

            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_ENDED) broadcast("ended", null);
                else if (playbackState == Player.STATE_BUFFERING) broadcast("buffering", null);
                else if (playbackState == Player.STATE_READY) broadcast(player.isPlaying() ? "playing" : "ready", null);
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                broadcast("error", error == null ? "Native playback failed." : error.getMessage());
            }
        });

        mediaSession = new MediaSession.Builder(this, player).build();
    }

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        // MediaSessionService marks this as @CallSuper because the base class handles
        // media-button/service bookkeeping. Older SidePlay versions skipped it.
        int baseResult = super.onStartCommand(intent, flags, startId);

        if (intent == null) return baseResult;
        String action = intent.getAction();

        if (ACTION_PLAY.equals(action)) {
            String url = intent.getStringExtra("url");
            String title = intent.getStringExtra("title");
            String artist = intent.getStringExtra("artist");
            String artwork = intent.getStringExtra("artwork");
            long positionMs = Math.max(0L, intent.getLongExtra("positionMs", 0L));

            if (url != null && !url.isBlank()) {
                MediaMetadata.Builder meta = new MediaMetadata.Builder()
                    .setTitle(title == null ? "SidePlay" : title)
                    .setArtist(artist == null ? "" : artist);
                if (artwork != null && !artwork.isBlank()) meta.setArtworkUri(Uri.parse(artwork));

                MediaItem item = new MediaItem.Builder()
                    .setUri(Uri.parse(url))
                    .setMediaMetadata(meta.build())
                    .build();

                player.setMediaItem(item, positionMs);
                player.prepare();
                player.play();
            }
            return START_STICKY;
        }

        if (ACTION_PAUSE.equals(action)) {
            player.pause();
            return START_STICKY;
        }

        if (ACTION_RESUME.equals(action)) {
            if (player.getMediaItemCount() > 0) player.play();
            return START_STICKY;
        }

        if (ACTION_STOP.equals(action)) {
            player.stop();
            player.clearMediaItems();
            stopSelf();
            return START_NOT_STICKY;
        }

        return baseResult;
    }

    @Override
    public void onTaskRemoved(@Nullable Intent rootIntent) {
        // Explicitly preserve active playback when SidePlay is swiped away.
        // If nothing is playing, terminate the service instead of leaving an idle
        // background service around.
        if (player != null && player.isPlaying()) return;
        stopSelf();
    }

    public void seekTo(long positionMs) {
        if (player == null) return;
        long duration = normalizedDuration();
        long target = Math.max(0L, positionMs);
        if (duration > 0L) target = Math.min(target, duration);
        player.seekTo(target);
    }

    public long getPositionMs() {
        return player == null ? 0L : Math.max(0L, player.getCurrentPosition());
    }

    public long getDurationMs() {
        return normalizedDuration();
    }

    public boolean isPlayingNow() {
        return player != null && player.isPlaying();
    }

    public int getPlaybackStateValue() {
        return player == null ? Player.STATE_IDLE : player.getPlaybackState();
    }

    private long normalizedDuration() {
        if (player == null) return 0L;
        long duration = player.getDuration();
        return duration == C.TIME_UNSET || duration < 0L ? 0L : duration;
    }

    private void broadcast(String state, @Nullable String message) {
        Intent event = new Intent(ACTION_EVENT);
        event.setPackage(getPackageName());
        event.putExtra("state", state);
        event.putExtra("positionMs", getPositionMs());
        event.putExtra("durationMs", getDurationMs());
        if (message != null && !message.isBlank()) event.putExtra("message", message);
        sendBroadcast(event);
    }

    @Nullable
    @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    @Override
    public void onDestroy() {
        instance = null;
        if (mediaSession != null) mediaSession.release();
        if (player != null) player.release();
        super.onDestroy();
    }
}
