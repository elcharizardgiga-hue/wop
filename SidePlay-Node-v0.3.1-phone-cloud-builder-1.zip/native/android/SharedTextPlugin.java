package app.sideplay.mobile;

import android.content.Intent;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "SharedText")
public class SharedTextPlugin extends Plugin {
    @PluginMethod
    public void getInitialShare(PluginCall call) {
        JSObject result = new JSObject();
        Intent intent = getActivity().getIntent();
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null) result.put("text", text);
        }
        call.resolve(result);
    }
}
