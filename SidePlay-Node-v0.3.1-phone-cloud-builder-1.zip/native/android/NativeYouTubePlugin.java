package app.sideplay.mobile;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

@CapacitorPlugin(name = "NativeYouTube")
public class NativeYouTubePlugin extends Plugin {
    private static final String UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36";

    @PluginMethod
    public void search(PluginCall call) {
        final String query = call.getString("query", "").trim();
        final Integer requested = call.getInt("limit", 25);
        final int limit = Math.max(1, Math.min(requested == null ? 25 : requested, 50));
        if (query.isEmpty()) {
            call.reject("Search query is empty.");
            return;
        }

        new Thread(() -> {
            StringBuilder failures = new StringBuilder();
            try {
                JSArray tracks = searchInnertube(query, limit);
                JSObject result = new JSObject();
                result.put("tracks", tracks);
                result.put("source", "youtube-innertube");
                call.resolve(result);
                return;
            } catch (Exception e) {
                failures.append("InnerTube: ").append(message(e));
            }

            try {
                String url = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8.toString()) + "&hl=en&gl=US";
                String html = get(url);
                JSONObject initial = new JSONObject(extractInitialData(html));
                JSArray tracks = new JSArray();
                collectVideoRenderers(initial, tracks, new HashSet<>(), limit);
                if (tracks.length() == 0) throw new Exception("HTML parser returned no videos");
                JSObject result = new JSObject();
                result.put("tracks", tracks);
                result.put("source", "youtube-html");
                call.resolve(result);
            } catch (Exception e) {
                failures.append(" | HTML: ").append(message(e));
                call.reject("Keyless YouTube search failed: " + failures);
            }
        }).start();
    }

    @PluginMethod
    public void getVideo(PluginCall call) {
        final String videoId = call.getString("videoId", "").trim();
        if (videoId.isEmpty()) {
            call.reject("videoId is required.");
            return;
        }
        new Thread(() -> {
            try {
                String watch = "https://www.youtube.com/watch?v=" + URLEncoder.encode(videoId, StandardCharsets.UTF_8.toString());
                String endpoint = "https://www.youtube.com/oembed?format=json&url=" + URLEncoder.encode(watch, StandardCharsets.UTF_8.toString());
                JSONObject meta = new JSONObject(get(endpoint));
                JSObject track = new JSObject();
                track.put("videoId", videoId);
                track.put("title", meta.optString("title", "YouTube video " + videoId));
                track.put("channel", meta.optString("author_name", "YouTube"));
                track.put("thumbnail", meta.optString("thumbnail_url", "https://i.ytimg.com/vi/" + videoId + "/hqdefault.jpg"));
                JSObject result = new JSObject();
                result.put("track", track);
                call.resolve(result);
            } catch (Exception e) {
                call.reject("Could not load video metadata: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
            }
        }).start();
    }

    private String message(Exception e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    private JSArray searchInnertube(String query, int limit) throws Exception {
        String clientVersion = "2.20260909.00.00";
        try {
            clientVersion = extractClientVersion(get("https://www.youtube.com/?hl=en&gl=US"));
        } catch (Exception ignored) {}

        JSONObject client = new JSONObject();
        client.put("clientName", "WEB");
        client.put("clientVersion", clientVersion);
        client.put("hl", "en");
        client.put("gl", "US");
        client.put("platform", "DESKTOP");

        JSONObject context = new JSONObject();
        context.put("client", client);
        JSONObject body = new JSONObject();
        body.put("context", context);
        body.put("query", query);

        JSONObject response = new JSONObject(postJson("https://www.youtube.com/youtubei/v1/search?prettyPrint=false", body.toString()));
        JSArray tracks = new JSArray();
        collectVideoRenderers(response, tracks, new HashSet<>(), limit);
        if (tracks.length() == 0) throw new Exception("InnerTube returned no video results");
        return tracks;
    }

    private String extractClientVersion(String html) {
        String value = findJsonStringValue(html, "INNERTUBE_CONTEXT_CLIENT_VERSION");
        if (!value.isEmpty()) return value;
        value = findJsonStringValue(html, "INNERTUBE_CLIENT_VERSION");
        if (!value.isEmpty()) return value;
        value = findJsonStringValue(html, "clientVersion");
        if (value.startsWith("2.")) return value;
        return "2.20260909.00.00";
    }

    private String findJsonStringValue(String text, String key) {
        String marker = "\"" + key + "\"";
        int at = text.indexOf(marker);
        while (at >= 0) {
            int colon = text.indexOf(':', at + marker.length());
            if (colon < 0) break;
            int quote = colon + 1;
            while (quote < text.length() && Character.isWhitespace(text.charAt(quote))) quote++;
            if (quote < text.length() && text.charAt(quote) == '"') {
                int end = quote + 1;
                boolean escaped = false;
                for (; end < text.length(); end++) {
                    char c = text.charAt(end);
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '"') return text.substring(quote + 1, end);
                }
            }
            at = text.indexOf(marker, at + marker.length());
        }
        return "";
    }

    private String postJson(String urlString, String body) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(15000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("User-Agent", UA);
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Origin", "https://www.youtube.com");
        conn.setRequestProperty("Referer", "https://www.youtube.com/");
        byte[] payload = body.getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(payload.length);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(payload);
        }
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder responseBody = new StringBuilder();
        if (stream != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) responseBody.append(line).append('\n');
            }
        }
        conn.disconnect();
        if (code < 200 || code >= 400) throw new Exception("HTTP " + code + ": " + responseBody.substring(0, Math.min(180, responseBody.length())));
        return responseBody.toString();
    }

    private String get(String urlString) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(15000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", UA);
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        conn.setRequestProperty("Accept", "text/html,application/json;q=0.9,*/*;q=0.8");
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder body = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) body.append(line).append('\n');
        } finally {
            conn.disconnect();
        }
        if (code < 200 || code >= 400) throw new Exception("HTTP " + code);
        return body.toString();
    }

    private String extractInitialData(String html) throws Exception {
        String[] markers = new String[] {
            "var ytInitialData",
            "window[\"ytInitialData\"]",
            "window['ytInitialData']",
            "ytInitialData"
        };
        int searchFrom = 0;

        while (searchFrom < html.length()) {
            int bestAt = -1;
            String bestMarker = null;
            for (String marker : markers) {
                int at = html.indexOf(marker, searchFrom);
                if (at >= 0 && (bestAt < 0 || at < bestAt)) {
                    bestAt = at;
                    bestMarker = marker;
                }
            }
            if (bestAt < 0 || bestMarker == null) break;
            searchFrom = bestAt + bestMarker.length();

            int i = searchFrom;
            while (i < html.length() && Character.isWhitespace(html.charAt(i))) i++;
            if (i >= html.length() || html.charAt(i) != '=') continue;
            i++;
            while (i < html.length() && Character.isWhitespace(html.charAt(i))) i++;
            if (i >= html.length() || html.charAt(i) != '{') continue;

            int start = i;
            int depth = 0;
            boolean inString = false;
            boolean escaped = false;
            for (; i < html.length(); i++) {
                char c = html.charAt(i);
                if (inString) {
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '"') inString = false;
                    continue;
                }
                if (c == '"') inString = true;
                else if (c == '{') depth++;
                else if (c == '}') {
                    depth--;
                    if (depth == 0) {
                        String candidate = html.substring(start, i + 1);
                        try {
                            JSONObject parsed = new JSONObject(candidate);
                            if (parsed.has("contents") || parsed.has("responseContext")) return candidate;
                        } catch (Exception ignored) {}
                        break;
                    }
                }
            }
        }
        throw new Exception("YouTube response did not contain valid ytInitialData");
    }

    private void collectVideoRenderers(Object node, JSArray out, Set<String> seen, int limit) throws Exception {
        if (out.length() >= limit || node == null) return;
        if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            JSONObject renderer = obj.optJSONObject("videoRenderer");
            if (renderer != null) addVideo(renderer, out, seen);
            if (out.length() >= limit) return;
            JSONArray names = obj.names();
            if (names == null) return;
            for (int i = 0; i < names.length() && out.length() < limit; i++) {
                collectVideoRenderers(obj.opt(names.optString(i)), out, seen, limit);
            }
        } else if (node instanceof JSONArray) {
            JSONArray array = (JSONArray) node;
            for (int i = 0; i < array.length() && out.length() < limit; i++) {
                collectVideoRenderers(array.opt(i), out, seen, limit);
            }
        }
    }

    private void addVideo(JSONObject r, JSArray out, Set<String> seen) {
        String id = r.optString("videoId", "");
        if (id.isEmpty() || seen.contains(id)) return;
        seen.add(id);

        JSObject track = new JSObject();
        track.put("videoId", id);
        track.put("title", text(r.optJSONObject("title"), "Untitled"));
        String channel = text(r.optJSONObject("ownerText"), "");
        if (channel.isEmpty()) channel = text(r.optJSONObject("shortBylineText"), "Unknown channel");
        track.put("channel", channel);
        track.put("thumbnail", thumbnail(r.optJSONObject("thumbnail"), id));
        out.put(track);
    }

    private String text(JSONObject obj, String fallback) {
        if (obj == null) return fallback;
        String simple = obj.optString("simpleText", "");
        if (!simple.isEmpty()) return simple;
        JSONArray runs = obj.optJSONArray("runs");
        if (runs != null && runs.length() > 0) {
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < runs.length(); i++) s.append(runs.optJSONObject(i) == null ? "" : runs.optJSONObject(i).optString("text", ""));
            if (s.length() > 0) return s.toString();
        }
        return fallback;
    }

    private String thumbnail(JSONObject obj, String id) {
        if (obj != null) {
            JSONArray thumbs = obj.optJSONArray("thumbnails");
            if (thumbs != null && thumbs.length() > 0) {
                JSONObject best = thumbs.optJSONObject(thumbs.length() - 1);
                if (best != null) {
                    String url = best.optString("url", "");
                    if (!url.isEmpty()) return url.startsWith("//") ? "https:" + url : url;
                }
            }
        }
        return "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg";
    }
}
