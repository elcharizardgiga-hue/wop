import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const android = path.join(root, 'android')
if (!fs.existsSync(android)) throw new Error('android/ does not exist. Run: npx cap add android')

const nativeFiles = ['PlaybackService.java', 'BackgroundAudioPlugin.java', 'SharedTextPlugin.java', 'NativeYouTubePlugin.java', 'DirectDownloadPlugin.java', 'OfflineMediaPlugin.java', 'WebPlaybackKeepAliveService.java', 'WebPlaybackPlugin.java', 'SpotifySessionListenerService.java', 'SpotifySessionPlugin.java']
for (const file of nativeFiles) {
  const source = path.join(root, 'native', 'android', file)
  if (!fs.existsSync(source)) throw new Error(`Missing native Android source: native/android/${file}. Re-extract a complete SidePlay release.`)
}

const pkgDir = path.join(android, 'app', 'src', 'main', 'java', 'app', 'sideplay', 'mobile')
fs.mkdirSync(pkgDir, { recursive: true })
for (const file of nativeFiles) {
  fs.copyFileSync(path.join(root, 'native', 'android', file), path.join(pkgDir, file))
}

const mainActivity = path.join(pkgDir, 'MainActivity.java')
fs.writeFileSync(mainActivity, `package app.sideplay.mobile;\n\nimport android.app.PictureInPictureParams;\nimport android.content.Intent;\nimport android.content.res.Configuration;\nimport android.os.Build;\nimport android.os.Bundle;\nimport android.os.Handler;\nimport android.os.Looper;\nimport android.util.Rational;\nimport android.webkit.WebSettings;\nimport android.webkit.WebView;\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {\n  private boolean webPlaybackWanted = false;\n  private boolean appVisible = true;\n  private boolean sidePlayPipEnabled = true;\n  private final Handler webPlaybackHandler = new Handler(Looper.getMainLooper());\n  private final Runnable webPlaybackPulse = new Runnable() {\n    @Override public void run() {\n      if (!webPlaybackWanted || appVisible) return;\n      keepWebViewRunning();\n      webPlaybackHandler.postDelayed(this, 4000L);\n    }\n  };\n\n  @Override\n  public void onCreate(Bundle savedInstanceState) {\n    registerPlugin(BackgroundAudioPlugin.class);\n    registerPlugin(SharedTextPlugin.class);\n    registerPlugin(NativeYouTubePlugin.class);\n    registerPlugin(DirectDownloadPlugin.class);\n    registerPlugin(OfflineMediaPlugin.class);\n    registerPlugin(WebPlaybackPlugin.class);
    registerPlugin(SpotifySessionPlugin.class);\n    super.onCreate(savedInstanceState);\n    configureWebPlayback();\n    updatePipParams();\n  }\n\n  public void setSidePlayPipEnabled(boolean enabled) {\n    sidePlayPipEnabled = enabled;\n    updatePipParams();\n  }\n\n  public void setWebPlaybackWanted(boolean wanted) {\n    webPlaybackWanted = wanted;\n    updatePipParams();\n    if (!wanted) {\n      webPlaybackHandler.removeCallbacks(webPlaybackPulse);\n      return;\n    }\n    configureWebPlayback();\n    if (!appVisible) {\n      keepWebViewRunning();\n      webPlaybackHandler.removeCallbacks(webPlaybackPulse);\n      webPlaybackHandler.postDelayed(webPlaybackPulse, 1200L);\n    }\n  }\n\n  private boolean pipEligible() {\n    return sidePlayPipEnabled && webPlaybackWanted && Build.VERSION.SDK_INT >= 26;\n  }\n\n  private void updatePipParams() {\n    if (Build.VERSION.SDK_INT < 26) return;\n    try {\n      PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder()\n          .setAspectRatio(new Rational(16, 9));\n      if (Build.VERSION.SDK_INT >= 31) {\n        builder.setAutoEnterEnabled(pipEligible());\n        builder.setSeamlessResizeEnabled(true);\n      }\n      setPictureInPictureParams(builder.build());\n    } catch (Exception ignored) {}\n  }\n\n  private void setPipUi(boolean active) {\n    if (getBridge() == null) return;\n    try {\n      getBridge().eval("window.__sideplaySetPipMode && window.__sideplaySetPipMode(" + active + ");", null);\n    } catch (Exception ignored) {}\n  }\n\n  private void configureWebPlayback() {\n    if (getBridge() == null || getBridge().getWebView() == null) return;\n    WebView webView = getBridge().getWebView();\n    WebSettings settings = webView.getSettings();\n    settings.setMediaPlaybackRequiresUserGesture(false);\n    if (Build.VERSION.SDK_INT >= 23) settings.setOffscreenPreRaster(true);\n    if (Build.VERSION.SDK_INT >= 26) {\n      webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);\n    }\n  }\n\n  private void keepWebViewRunning() {\n    if (!webPlaybackWanted || getBridge() == null || getBridge().getWebView() == null) return;\n    WebView webView = getBridge().getWebView();\n    try {\n      configureWebPlayback();\n      webView.onResume();\n      webView.resumeTimers();\n      getBridge().eval("window.__sideplayBackgroundNudge && window.__sideplayBackgroundNudge();", null);\n    } catch (Exception ignored) {}\n  }\n\n  @Override\n  protected void onUserLeaveHint() {\n    if (pipEligible() && Build.VERSION.SDK_INT < 31 && !isInPictureInPictureMode()) {\n      try {\n        setPipUi(true);\n        enterPictureInPictureMode(new PictureInPictureParams.Builder()\n            .setAspectRatio(new Rational(16, 9))\n            .build());\n      } catch (Exception ignored) {}\n    }\n    super.onUserLeaveHint();\n  }\n\n  @Override\n  public void onPictureInPictureModeChanged(boolean inPip, Configuration newConfig) {\n    super.onPictureInPictureModeChanged(inPip, newConfig);\n    setPipUi(inPip);\n    if (inPip && webPlaybackWanted) {\n      appVisible = true;\n      keepWebViewRunning();\n    }\n  }\n\n  @Override\n  public void onResume() {\n    appVisible = true;\n    webPlaybackHandler.removeCallbacks(webPlaybackPulse);\n    super.onResume();\n    configureWebPlayback();\n    updatePipParams();\n    if (!isInPictureInPictureMode()) setPipUi(false);\n  }\n\n  @Override\n  public void onPause() {\n    super.onPause();\n    appVisible = isInPictureInPictureMode();\n    if (webPlaybackWanted) {\n      keepWebViewRunning();\n      if (!appVisible) {\n        webPlaybackHandler.removeCallbacks(webPlaybackPulse);\n        webPlaybackHandler.postDelayed(webPlaybackPulse, 700L);\n      }\n    }\n  }\n\n  @Override\n  public void onStop() {\n    super.onStop();\n    appVisible = isInPictureInPictureMode();\n    if (webPlaybackWanted && !appVisible) {\n      keepWebViewRunning();\n      webPlaybackHandler.removeCallbacks(webPlaybackPulse);\n      webPlaybackHandler.postDelayed(webPlaybackPulse, 900L);\n    }\n  }\n\n  @Override\n  public void onTrimMemory(int level) {\n    super.onTrimMemory(level);\n    if (webPlaybackWanted && level >= TRIM_MEMORY_UI_HIDDEN) keepWebViewRunning();\n  }\n\n  @Override\n  protected void onActivityResult(int requestCode, int resultCode, Intent data) {\n    if (OfflineMediaPlugin.handleActivityResult(requestCode, resultCode, data)) return;\n    super.onActivityResult(requestCode, resultCode, data);\n  }\n\n  @Override\n  protected void onNewIntent(Intent intent) {\n    super.onNewIntent(intent);\n    setIntent(intent);\n  }\n\n  @Override\n  public void onDestroy() {\n    webPlaybackHandler.removeCallbacks(webPlaybackPulse);\n    setPipUi(false);\n    super.onDestroy();\n  }\n}\n`)

const gradle = path.join(android, 'app', 'build.gradle')
let g = fs.readFileSync(gradle, 'utf8')
if (!g.includes('media3-exoplayer')) {
  g = g.replace(/dependencies\s*\{/, `dependencies {\n    implementation "androidx.media3:media3-exoplayer:1.8.1"\n    implementation "androidx.media3:media3-session:1.8.1"`)
}

fs.writeFileSync(gradle, g)

const manifest = path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml')
let m = fs.readFileSync(manifest, 'utf8')
const perms = [
  '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
  '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />',
  '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  '<uses-permission android:name="android.permission.WAKE_LOCK" />'
]
for (const p of perms) if (!m.includes(p)) m = m.replace(/<application/, `    ${p}\n    <application`)

// Picture-in-Picture support for the main Capacitor Activity.
m = m.replace(/<activity\b([\s\S]*?)android:name="\.MainActivity"([\s\S]*?)>/, (full, before, after) => {
  let attrs = before + 'android:name=".MainActivity"' + after
  if (!attrs.includes('android:supportsPictureInPicture=')) attrs += '\n            android:supportsPictureInPicture="true"'
  const required = ['screenSize', 'smallestScreenSize', 'screenLayout', 'orientation']
  const configMatch = attrs.match(/android:configChanges="([^"]*)"/)
  if (configMatch) {
    const parts = configMatch[1].split('|').filter(Boolean)
    for (const item of required) if (!parts.includes(item)) parts.push(item)
    attrs = attrs.replace(/android:configChanges="[^"]*"/, `android:configChanges="${parts.join('|')}"`)
  } else {
    attrs += `\n            android:configChanges="${required.join('|')}"`
  }
  return '<activity' + attrs + '>'
})

if (!m.includes('PlaybackService')) {
  m = m.replace(/<\/application>/, `        <service\n            android:name=".PlaybackService"\n            android:stopWithTask="false"\n            android:foregroundServiceType="mediaPlayback"\n            android:exported="true">\n            <intent-filter>\n                <action android:name="androidx.media3.session.MediaSessionService" />\n            </intent-filter>\n        </service>\n    </application>`)
} else if (!/android:name="\.PlaybackService"[\s\S]*?android:stopWithTask=/.test(m)) {
  m = m.replace(/android:name="\.PlaybackService"/, 'android:name=".PlaybackService"\n            android:stopWithTask="false"')
}

if (!m.includes('WebPlaybackKeepAliveService')) {
  m = m.replace(/<\/application>/, `        <service
            android:name=".WebPlaybackKeepAliveService"
            android:stopWithTask="true"
            android:foregroundServiceType="mediaPlayback"
            android:exported="false" />
    </application>`)
}
if (!m.includes('com.spotify.music')) {
  m = m.replace(/<application/, `    <queries>
        <package android:name="com.spotify.music" />
    </queries>
    <application`)
}
if (!m.includes('SpotifySessionListenerService')) {
  m = m.replace(/<\/application>/, `        <service
            android:name=".SpotifySessionListenerService"
            android:label="SidePlay Spotify control"
            android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.service.notification.NotificationListenerService" />
            </intent-filter>
        </service>
    </application>`)
}
if (!m.includes('android.intent.action.SEND')) {
  m = m.replace(/(<activity[\s\S]*?<intent-filter>[\s\S]*?<\/intent-filter>)/, `$1\n            <intent-filter>\n                <action android:name="android.intent.action.SEND" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <data android:mimeType="text/plain" />\n            </intent-filter>`)
}
fs.writeFileSync(manifest, m)
console.log('Android project patched: Media3 + Spotify MediaSession engine + compact auto-PiP fallback + WebView keep-alive, keyless search, offline vault, downloads, and Share intent.')
