import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { URL } from 'node:url'

const HOST = process.env.SIDEPLAY_PC_HOST || '127.0.0.1'
const PORT = Number(process.env.SIDEPLAY_PC_PORT || 4783)
const OFFLINE_DIR = process.env.SIDEPLAY_OFFLINE_DIR || path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'SidePlay', 'offline')
fs.mkdirSync(OFFLINE_DIR, { recursive: true })
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36'
const defaultInstances = ['https://inv.nadeko.net', 'https://invidious.nerdvpn.de']
const invidiousInstances = (process.env.SIDEPLAY_INVIDIOUS_INSTANCES || defaultInstances.join(','))
  .split(',').map(x => x.trim().replace(/\/$/, '')).filter(Boolean)

function json(res, status, body) {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(payload),
    'access-control-allow-origin': '*',
    'access-control-allow-methods': 'GET,POST,DELETE,OPTIONS',
    'access-control-allow-headers': 'content-type,x-sideplay-filename',
    'cache-control': 'no-store',
  })
  res.end(payload)
}

async function fetchText(url, accept = 'text/html,application/json;q=0.9,*/*;q=0.8') {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 15000)
  try {
    const response = await fetch(url, {
      redirect: 'follow',
      headers: {
        'user-agent': UA,
        'accept-language': 'en-US,en;q=0.9',
        accept,
      },
      signal: controller.signal,
    })
    const text = await response.text()
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    return text
  } finally {
    clearTimeout(timer)
  }
}

async function postJson(url, body) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 15000)
  try {
    const response = await fetch(url, {
      method: 'POST',
      redirect: 'follow',
      headers: {
        'user-agent': UA,
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/json',
        'origin': 'https://www.youtube.com',
        'referer': 'https://www.youtube.com/',
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    })
    const text = await response.text()
    if (!response.ok) throw new Error(`HTTP ${response.status}: ${text.slice(0, 180)}`)
    try { return JSON.parse(text) }
    catch { throw new Error(`YouTube returned non-JSON search data: ${text.slice(0, 120)}`) }
  } finally {
    clearTimeout(timer)
  }
}

function extractClientVersion(html) {
  const patterns = [
    /\"INNERTUBE_CONTEXT_CLIENT_VERSION\"\s*:\s*\"([^\"]+)\"/,
    /\"INNERTUBE_CLIENT_VERSION\"\s*:\s*\"([^\"]+)\"/,
    /\"clientVersion\"\s*:\s*\"(2\.[0-9.]+)\"/,
  ]
  for (const pattern of patterns) {
    const match = html.match(pattern)
    if (match?.[1]) return match[1]
  }
  return '2.20260909.00.00'
}

async function searchYouTubeInnertube(query, limit) {
  // Bootstrap the current WEB client version from YouTube itself. This is much
  // less brittle than scraping ytInitialData and the search endpoint currently
  // accepts signed-out WEB requests without a developer API key.
  let clientVersion = '2.20260909.00.00'
  try {
    const homepage = await fetchText('https://www.youtube.com/?hl=en&gl=US')
    clientVersion = extractClientVersion(homepage)
  } catch {}

  const response = await postJson('https://www.youtube.com/youtubei/v1/search?prettyPrint=false', {
    context: {
      client: {
        clientName: 'WEB',
        clientVersion,
        hl: 'en',
        gl: 'US',
        platform: 'DESKTOP',
      },
    },
    query,
  })

  const tracks = []
  collectVideos(response, tracks, new Set(), limit)
  if (!tracks.length) throw new Error('InnerTube returned no video results')
  return tracks
}

function extractInitialData(html) {
  // Fallback only. YouTube can mention the text "ytInitialData =" inside other
  // scripts, so never jump to the next random "{". Require an actual assignment
  // whose first non-whitespace character is a JSON object and validate candidates.
  const markers = [
    'var ytInitialData',
    'window["ytInitialData"]',
    "window['ytInitialData']",
    'ytInitialData',
  ]
  let searchFrom = 0

  while (searchFrom < html.length) {
    let best = null
    for (const marker of markers) {
      const at = html.indexOf(marker, searchFrom)
      if (at >= 0 && (!best || at < best.at)) best = { at, marker }
    }
    if (!best) break
    searchFrom = best.at + best.marker.length

    let i = searchFrom
    while (i < html.length && /\s/.test(html[i])) i++
    if (html[i] !== '=') continue
    i++
    while (i < html.length && /\s/.test(html[i])) i++
    if (html[i] !== '{') continue

    const start = i
    let depth = 0
    let inString = false
    let escaped = false
    for (; i < html.length; i++) {
      const c = html[i]
      if (inString) {
        if (escaped) escaped = false
        else if (c === '\\') escaped = true
        else if (c === '"') inString = false
        continue
      }
      if (c === '"') inString = true
      else if (c === '{') depth++
      else if (c === '}') {
        depth--
        if (depth === 0) {
          const candidate = html.slice(start, i + 1)
          try {
            const parsed = JSON.parse(candidate)
            if (parsed && typeof parsed === 'object' && (parsed.contents || parsed.responseContext)) return candidate
          } catch {}
          break
        }
      }
    }
  }
  throw new Error('YouTube response did not contain valid ytInitialData')
}

function textFrom(obj, fallback = '') {
  if (!obj || typeof obj !== 'object') return fallback
  if (typeof obj.simpleText === 'string' && obj.simpleText) return obj.simpleText
  if (Array.isArray(obj.runs)) {
    const text = obj.runs.map(run => run?.text || '').join('')
    if (text) return text
  }
  return fallback
}

function thumbFrom(obj, id) {
  const thumbs = obj?.thumbnails
  if (Array.isArray(thumbs) && thumbs.length) {
    const best = thumbs[thumbs.length - 1]
    if (best?.url) return best.url.startsWith('//') ? `https:${best.url}` : best.url
  }
  return `https://i.ytimg.com/vi/${id}/hqdefault.jpg`
}

function collectVideos(node, out, seen, limit) {
  if (!node || out.length >= limit) return
  if (Array.isArray(node)) {
    for (const item of node) {
      collectVideos(item, out, seen, limit)
      if (out.length >= limit) return
    }
    return
  }
  if (typeof node !== 'object') return

  const r = node.videoRenderer
  if (r?.videoId && !seen.has(r.videoId)) {
    seen.add(r.videoId)
    out.push({
      videoId: r.videoId,
      title: textFrom(r.title, 'Untitled'),
      channel: textFrom(r.ownerText, textFrom(r.shortBylineText, 'Unknown channel')),
      thumbnail: thumbFrom(r.thumbnail, r.videoId),
    })
    if (out.length >= limit) return
  }

  for (const value of Object.values(node)) {
    collectVideos(value, out, seen, limit)
    if (out.length >= limit) return
  }
}

async function searchYouTubeHtml(query, limit) {
  const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}&hl=en&gl=US`
  const html = await fetchText(url)
  const initial = JSON.parse(extractInitialData(html))
  const tracks = []
  collectVideos(initial, tracks, new Set(), limit)
  if (!tracks.length) throw new Error('No video results found in YouTube response')
  return tracks
}

function normalizeInvidiousVideo(item) {
  const thumbs = Array.isArray(item.videoThumbnails) ? item.videoThumbnails : []
  const best = thumbs.find(t => t.quality === 'medium') || thumbs.find(t => t.quality === 'high') || thumbs[0]
  return {
    videoId: item.videoId,
    title: item.title || 'Untitled',
    channel: item.author || 'Unknown channel',
    thumbnail: best?.url || `https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg`,
    publishedAt: item.published ? new Date(Number(item.published) * 1000).toISOString() : undefined,
  }
}

async function searchInvidious(query, limit) {
  const failures = []
  for (const instance of invidiousInstances) {
    try {
      const url = `${instance}/api/v1/search?q=${encodeURIComponent(query)}&type=video&page=1&sort=relevance`
      const data = JSON.parse(await fetchText(url, 'application/json'))
      const tracks = (Array.isArray(data) ? data : [])
        .filter(item => item?.type === 'video' && item.videoId)
        .slice(0, limit)
        .map(normalizeInvidiousVideo)
      if (tracks.length) return { tracks, source: `invidious:${new URL(instance).host}` }
      failures.push(`${instance}: no video results`)
    } catch (error) {
      failures.push(`${instance}: ${error?.message || String(error)}`)
    }
  }
  throw new Error(`Invidious fallback failed (${failures.join('; ')})`)
}

async function search(query, limit) {
  const failures = []
  try {
    const tracks = await searchYouTubeInnertube(query, limit)
    return { tracks, source: 'youtube-innertube' }
  } catch (error) {
    failures.push(`InnerTube: ${error?.message || error}`)
  }
  try {
    const tracks = await searchYouTubeHtml(query, limit)
    return { tracks, source: 'youtube-html' }
  } catch (error) {
    failures.push(`HTML: ${error?.message || error}`)
  }
  try {
    return await searchInvidious(query, limit)
  } catch (error) {
    failures.push(error?.message || String(error))
  }
  throw new Error(`Keyless search failed (${failures.join(' | ')})`)
}

async function getVideo(videoId) {
  const watch = `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`
  const endpoint = `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(watch)}`
  try {
    const meta = JSON.parse(await fetchText(endpoint, 'application/json'))
    return {
      videoId,
      title: meta.title || `YouTube video ${videoId}`,
      channel: meta.author_name || 'YouTube',
      thumbnail: meta.thumbnail_url || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    }
  } catch {
    return {
      videoId,
      title: `YouTube video ${videoId}`,
      channel: 'YouTube',
      thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    }
  }
}

function safeFileName(value) {
  return String(value || 'audio').replace(/[\\/:*?"<>|\x00-\x1f]/g, '_').slice(0, 180)
}

function offlinePathFromUri(raw) {
  try {
    const u = new URL(raw)
    if (u.hostname !== HOST || Number(u.port || 80) !== PORT || !u.pathname.startsWith('/offline/')) return null
    const name = path.basename(decodeURIComponent(u.pathname.slice('/offline/'.length)))
    const target = path.resolve(OFFLINE_DIR, name)
    const root = path.resolve(OFFLINE_DIR) + path.sep
    return target.startsWith(root) ? target : null
  } catch { return null }
}

async function streamBodyToFile(req, finalPath, maxBytes = 512 * 1024 * 1024) {
  const declared = Number(req.headers['content-length'] || 0)
  if (declared > maxBytes) throw new Error('File is too large for the SidePlay PC vault (512 MB max).')

  const tempPath = `${finalPath}.partial-${process.pid}-${Date.now()}`
  let total = 0
  const output = fs.createWriteStream(tempPath, { flags: 'wx' })
  try {
    for await (const chunk of req) {
      total += chunk.length
      if (total > maxBytes) throw new Error('File is too large for the SidePlay PC vault (512 MB max).')
      if (!output.write(chunk)) await new Promise((resolve, reject) => { output.once('drain', resolve); output.once('error', reject) })
    }
    await new Promise((resolve, reject) => output.end((err) => err ? reject(err) : resolve()))
    if (total <= 0) throw new Error('The selected audio file was empty.')
    fs.renameSync(tempPath, finalPath)
    return total
  } catch (error) {
    try { output.destroy() } catch {}
    try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath) } catch {}
    throw error
  }
}

function serveOffline(req, res, file) {
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return json(res, 404, { error: 'Offline file not found' })
  const stat = fs.statSync(file)
  const ext = path.extname(file).toLowerCase()
  const mime = ({'.mp3':'audio/mpeg','.m4a':'audio/mp4','.aac':'audio/aac','.ogg':'audio/ogg','.opus':'audio/ogg','.flac':'audio/flac','.wav':'audio/wav','.webm':'audio/webm'})[ext] || 'application/octet-stream'
  const range = req.headers.range
  if (range) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(range)
    if (match) {
      const start = match[1] ? Number(match[1]) : 0
      const end = match[2] ? Math.min(Number(match[2]), stat.size - 1) : stat.size - 1
      if (Number.isFinite(start) && Number.isFinite(end) && start <= end && start < stat.size) {
        res.writeHead(206, {
          'content-type': mime,
          'content-length': end - start + 1,
          'content-range': `bytes ${start}-${end}/${stat.size}`,
          'accept-ranges': 'bytes',
          'cache-control': 'private, max-age=3600',
          'access-control-allow-origin': '*',
        })
        fs.createReadStream(file, { start, end }).pipe(res)
        return
      }
    }
    res.writeHead(416, { 'content-range': `bytes */${stat.size}` }); res.end(); return
  }
  res.writeHead(200, {
    'content-type': mime,
    'content-length': stat.size,
    'accept-ranges': 'bytes',
    'cache-control': 'private, max-age=3600',
    'access-control-allow-origin': '*',
  })
  fs.createReadStream(file).pipe(res)
}


async function readJson(req, maxBytes = 64 * 1024) {
  const chunks = []
  let total = 0
  for await (const chunk of req) {
    total += chunk.length
    if (total > maxBytes) throw new Error('Request body is too large.')
    chunks.push(chunk)
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}') }
  catch { throw new Error('Invalid JSON request.') }
}

function isBlockedDownloadHost(hostname) {
  const host = hostname.toLowerCase()
  return host === 'youtube.com' || host.endsWith('.youtube.com') || host === 'youtu.be' || host.endsWith('.googlevideo.com')
}

function filenameFromResponse(url, headers, requested) {
  if (requested) return safeFileName(requested)
  const disposition = headers.get('content-disposition') || ''
  const utf = disposition.match(/filename\*=UTF-8''([^;]+)/i)
  if (utf?.[1]) {
    try { return safeFileName(decodeURIComponent(utf[1].replace(/^"|"$/g, ''))) } catch {}
  }
  const plain = disposition.match(/filename="?([^";]+)"?/i)
  if (plain?.[1]) return safeFileName(plain[1])
  try {
    const name = path.basename(new URL(url).pathname)
    if (name && name !== '/') return safeFileName(decodeURIComponent(name))
  } catch {}
  return `SidePlay-${Date.now()}.media`
}

async function downloadDirectFile(rawUrl, requestedName) {
  let parsed
  try { parsed = new URL(rawUrl) } catch { throw new Error('Enter a valid direct media URL.') }
  if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Only http(s) direct media URLs are supported.')
  if (isBlockedDownloadHost(parsed.hostname)) throw new Error('YouTube media downloads are not supported by SidePlay.')

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 5 * 60 * 1000)
  let response
  try {
    response = await fetch(parsed, {
      redirect: 'follow',
      headers: { 'user-agent': UA, accept: 'audio/*,video/*,application/octet-stream;q=0.9,*/*;q=0.2' },
      signal: controller.signal,
    })
    if (!response.ok) throw new Error(`Remote server returned HTTP ${response.status}.`)
    const type = (response.headers.get('content-type') || '').toLowerCase()
    if (type.includes('text/html') || type.includes('application/json')) throw new Error(`That URL returned ${type || 'a web page'}, not a direct media file.`)
    const length = Number(response.headers.get('content-length') || 0)
    const maxBytes = 1024 * 1024 * 1024
    if (length > maxBytes) throw new Error('Direct download is larger than SidePlay\'s 1 GB limit.')

    const downloads = path.join(os.homedir(), 'Downloads', 'SidePlay')
    fs.mkdirSync(downloads, { recursive: true })
    let name = filenameFromResponse(response.url || rawUrl, response.headers, requestedName)
    if (!path.extname(name)) {
      const ext = type.startsWith('audio/mpeg') ? '.mp3' : type.startsWith('audio/mp4') ? '.m4a' : type.startsWith('audio/ogg') ? '.ogg' : type.startsWith('video/mp4') ? '.mp4' : '.media'
      name += ext
    }
    let finalPath = path.join(downloads, name)
    if (fs.existsSync(finalPath)) {
      const ext = path.extname(name); const base = path.basename(name, ext)
      finalPath = path.join(downloads, `${base}-${Date.now()}${ext}`)
    }
    const temp = `${finalPath}.partial`
    const out = fs.createWriteStream(temp, { flags: 'wx' })
    let total = 0
    try {
      if (!response.body) throw new Error('Remote server returned no file body.')
      for await (const chunk of response.body) {
        total += chunk.length
        if (total > maxBytes) throw new Error('Direct download exceeded SidePlay\'s 1 GB limit.')
        if (!out.write(chunk)) await new Promise((resolve, reject) => { out.once('drain', resolve); out.once('error', reject) })
      }
      await new Promise((resolve, reject) => out.end(err => err ? reject(err) : resolve()))
      if (!total) throw new Error('Remote server returned an empty file.')
      fs.renameSync(temp, finalPath)
      return { id: `pc-${Date.now()}`, destination: finalPath, bytes: total }
    } catch (error) {
      try { out.destroy() } catch {}
      try { if (fs.existsSync(temp)) fs.unlinkSync(temp) } catch {}
      throw error
    }
  } finally {
    clearTimeout(timer)
  }
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return json(res, 204, {})

  try {
    const url = new URL(req.url || '/', `http://${HOST}:${PORT}`)

    if (req.method === 'GET' && url.pathname === '/health') {
      return json(res, 200, { ok: true, service: 'sideplay-pc-bridge', version: '0.2.1', offlineDir: OFFLINE_DIR })
    }
    if (req.method === 'GET' && url.pathname === '/api/search') {
      const query = (url.searchParams.get('q') || '').trim()
      const limit = Math.max(1, Math.min(Number(url.searchParams.get('limit') || 25) || 25, 50))
      if (!query) return json(res, 400, { error: 'q is required' })
      const result = await search(query, limit)
      return json(res, 200, result)
    }
    if (req.method === 'GET' && url.pathname === '/api/video') {
      const videoId = (url.searchParams.get('id') || '').trim()
      if (!/^[A-Za-z0-9_-]{11}$/.test(videoId)) return json(res, 400, { error: 'valid 11-character video id is required' })
      return json(res, 200, { track: await getVideo(videoId) })
    }
    if (req.method === 'POST' && url.pathname === '/api/offline/import') {
      const key = safeFileName(url.searchParams.get('key') || `track-${Date.now()}`)
      let original = 'audio'
      try { original = decodeURIComponent(req.headers['x-sideplay-filename'] || 'audio') } catch {}
      const ext = path.extname(safeFileName(original)).slice(0, 12)
      const name = `${key}${ext || '.audio'}`
      const file = path.join(OFFLINE_DIR, name)
      const bytes = await streamBodyToFile(req, file)
      return json(res, 200, {
        localUri: `http://${HOST}:${PORT}/offline/${encodeURIComponent(name)}`,
        filename: safeFileName(original),
        mimeType: req.headers['content-type'] || 'application/octet-stream',
        bytes,
      })
    }
    if (req.method === 'DELETE' && url.pathname === '/api/offline') {
      const file = offlinePathFromUri(url.searchParams.get('uri') || '')
      if (!file) return json(res, 400, { error: 'Invalid SidePlay offline URI' })
      if (!fs.existsSync(file)) return json(res, 404, { error: 'Offline file not found' })
      fs.unlinkSync(file)
      return json(res, 200, { ok: true })
    }
    if (req.method === 'GET' && url.pathname.startsWith('/offline/')) {
      const name = path.basename(decodeURIComponent(url.pathname.slice('/offline/'.length)))
      const file = path.resolve(OFFLINE_DIR, name)
      const root = path.resolve(OFFLINE_DIR) + path.sep
      if (!file.startsWith(root)) return json(res, 400, { error: 'Invalid offline path' })
      return serveOffline(req, res, file)
    }
    if (req.method === 'POST' && url.pathname === '/api/direct-download') {
      const body = await readJson(req)
      const rawUrl = String(body?.url || '').trim()
      if (!rawUrl) return json(res, 400, { error: 'url is required' })
      const result = await downloadDirectFile(rawUrl, body?.filename ? String(body.filename) : '')
      return json(res, 200, result)
    }
    return json(res, 404, { error: 'Not found' })
  } catch (error) {
    return json(res, 502, { error: error?.message || String(error) })
  }
})

server.listen(PORT, HOST, () => {
  console.log(`[SidePlay PC bridge] http://${HOST}:${PORT}`)
  console.log(`[SidePlay offline vault] ${OFFLINE_DIR}`)
})

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => process.exit(0)))
}
