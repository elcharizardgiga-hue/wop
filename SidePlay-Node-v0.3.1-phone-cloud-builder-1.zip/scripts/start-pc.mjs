import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import { rm } from 'node:fs/promises'
import { join } from 'node:path'
import process from 'node:process'

const isWin = process.platform === 'win32'
const children = new Set()
let shuttingDown = false

async function cleanLegacyTools() {
  const legacy = join(process.cwd(), '.tools')
  if (!existsSync(legacy)) return

  try {
    await rm(legacy, { recursive: true, force: true, maxRetries: 2, retryDelay: 150 })
    console.log('[SidePlay] Removed legacy in-project .tools cache.')
  } catch {
    // Do not block startup if Windows/AV still has an old SDK archive locked.
    // Vite's watcher now ignores this path with a function-based filter.
    console.warn('[SidePlay] Legacy .tools is locked; leaving it alone. It is excluded from Vite watching.')
  }
}

function launch(command, args, name) {
  const child = spawn(command, args, {
    cwd: process.cwd(),
    stdio: 'inherit',
    windowsHide: false,
    shell: false,
  })
  child.__sideplayName = name
  children.add(child)
  child.on('exit', (code, signal) => {
    children.delete(child)
    if (!shuttingDown && name === 'Vite') shutdown(code ?? (signal ? 1 : 0))
  })
  return child
}

function shutdown(code = 0) {
  if (shuttingDown) return
  shuttingDown = true
  for (const child of children) {
    try {
      if (isWin && child.pid) {
        spawn('taskkill', ['/pid', String(child.pid), '/t', '/f'], { stdio: 'ignore', windowsHide: true })
      } else {
        child.kill('SIGTERM')
      }
    } catch {}
  }
  setTimeout(() => process.exit(code), 250)
}

await cleanLegacyTools()
console.log('Starting SidePlay PC search bridge + web app...')
launch(process.execPath, ['scripts/pc-search-server.mjs'], 'Search bridge')
launch(process.execPath, ['node_modules/vite/bin/vite.js', '--host', '0.0.0.0'], 'Vite')

process.on('SIGINT', () => shutdown(0))
process.on('SIGTERM', () => shutdown(0))
process.on('exit', () => {
  for (const child of children) {
    try { child.kill() } catch {}
  }
})
